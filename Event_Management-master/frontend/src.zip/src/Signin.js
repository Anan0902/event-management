import React, { useState } from 'react';
import './SignIn.css';

const SignIn = () => {
  const [role, setRole] = useState('participant');

  return (
    <div className="signin-container">
      <h2>Sign In to DAP</h2>
      <div className="role-toggle">
        <button onClick={() => setRole('participant')} className={role === 'participant' ? 'active' : ''}>Participant</button>
        <button onClick={() => setRole('host')} className={role === 'host' ? 'active' : ''}>Host</button>
      </div>

      {role === 'participant' ? (
        <form className="form">
          <input type="text" placeholder="Username or Email" />
          <input type="password" placeholder="Password" />
          <input type="text" placeholder="College (optional)" />
          <input type="text" placeholder="First Name" />
          <input type="text" placeholder="Last Name" />
          <input type="text" placeholder="Phone Number" />
          <input type="password" placeholder="Create Password" />
          <button type="submit">Sign In</button>
        </form>
      ) : (
        <form className="form">
          <input type="text" placeholder="Name of Host" />
          <input type="email" placeholder="Email ID" />
          <input type="password" placeholder="Password" />
          <input type="password" placeholder="Create Password" />
          <input type="text" placeholder="Organizer" />
          <input type="text" placeholder="Address" />
          <button type="submit">Submit</button>
        </form>
      )}
    </div>
  );
};

export default SignIn;
