import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './Navbar';
import LoginPage from './LoginPage';
import SignInPage from './SignInPage';
import WelcomePage from './WelcomePage';
import AccountChoice from './AccountChoice';
import SignupHost from './SignupHost.jsx';
import SignupParticipant from './SignupParicipant.js'; // double check the filename if needed
import AboutUs from './AboutUs'; // Import it at the top

// Inside <Routes>


import './App.css';

const App = () => {
  return (
    <Router>
      <div className="app-container">
        <Navbar />
        <main className="main-content">
          <Routes>
            <Route path="/" element={<WelcomePage />} />
            <Route path="/login" element={<LoginPage />} />
            <Route path="/about" element={<AboutUs />} />
            <Route path="/account-choice" element={<AccountChoice />} />
            <Route path="/signin" element={<SignInPage />} />
            <Route path="/signup-host" element={<SignupHost />} />
            <Route path="/signup-participant" element={<SignupParticipant />} />
          </Routes>
        </main>
      </div>
    </Router>
  );
};

export default App;
