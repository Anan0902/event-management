// src/SignUpHost.jsx
import React, { useState } from 'react';
import './SignUpForm.css';

const SignUpHost = () => {
  const [formData, setFormData] = useState({
    hostName: '',
    email: '',
    password: '',
    confirmPassword: '',
    organizer: '',
    address: ''
  });

  const handleChange = (e) => {
    setFormData(prev => ({
      ...prev,
      [e.target.name]: e.target.value
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log(formData);
  };

  return (
    <div className="signup-form-container">
      <h2>Host Sign Up</h2>
      <form onSubmit={handleSubmit}>
        <input name="hostName" placeholder="Host Name" onChange={handleChange} />
        <input name="email" type="email" placeholder="Email" onChange={handleChange} />
        <input name="organizer" placeholder="Organizer" onChange={handleChange} />
        <input name="address" placeholder="Address" onChange={handleChange} />
        <input name="password" type="password" placeholder="Password" onChange={handleChange} />
        <input name="confirmPassword" type="password" placeholder="Confirm Password" onChange={handleChange} />
        <button type="submit">Create Account</button>
      </form>
    </div>
  );
};

export default SignUpHost;
