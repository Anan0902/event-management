import React from 'react';
import './AboutUs.css';

const AboutUs = () => {
  return (
    <div className="aboutus-container">
      <h1>About DAP</h1>
      <p>DAP (Digital Event Platform) is a modern event management website designed to streamline event hosting and participation.</p>
      <h2>Features:</h2>
      <ul>
        <li>🎉 Easy event creation and management for hosts</li>
        <li>📅 Seamless event discovery and booking for participants</li>
        <li>🔐 Secure login and account switching for different roles</li>
        <li>🌐 Elegant, responsive design with themed animations</li>
      </ul>
    </div>
  );
};

export default AboutUs;
