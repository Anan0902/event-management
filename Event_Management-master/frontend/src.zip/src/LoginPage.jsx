import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './LoginPage.css';

const LoginPage = () => {
  const [emailOrUsername, setEmailOrUsername] = useState('');
  const [password, setPassword] = useState('');
  const navigate = useNavigate();

  const handleLogin = () => {
    alert('Login button clicked!');
  };

  const handleSignIn = () => {
    navigate('/account-choice');
  };

  return (
    <div className="login-page">
      <div className="login-box">
        <h1 className="title">
          Welcome to <span className="dap-highlight">DAP</span>
        </h1>

        <div className="input-container">
          <input
            id="emailOrUsername"
            type="text"
            placeholder="Username or Email"
            value={emailOrUsername}
            onChange={(e) => setEmailOrUsername(e.target.value)}
            className="input-field"
          />
        </div>

        <div className="input-container">
          <input
            id="password"
            type="password"
            placeholder="Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="input-field"
          />
        </div>

        <button className="login-button" onClick={handleLogin}>
          Login
        </button>

        <button className="signin-button" onClick={handleSignIn}>
          Sign In
        </button>
      </div>
    </div>
  );
};

export default LoginPage;
