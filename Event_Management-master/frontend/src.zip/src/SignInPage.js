import { useLocation } from 'react-router-dom';

const SignInPage = () => {
  const location = useLocation();
  const role = location.state?.role;

  if (!role) return <p>No role selected. Please go back.</p>;

  return (
    <form>
      <h2>Sign In as {role}</h2>
      {/* Render form fields based on role */}
      {role === 'participant' ? (
        <>
          <input placeholder="Username" />
          <input placeholder="Email" />
          {/* other participant fields */}
        </>
      ) : (
        <>
          <input placeholder="Host Name" />
          <input placeholder="Organizer" />
          {/* other host fields */}
        </>
      )}
      <button type="submit">Sign In</button>
    </form>
  );
};
export default SignInPage;
